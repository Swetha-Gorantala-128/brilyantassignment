import csv

def calculate_average_grade(csv_file):
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header row
        grades = [int(row[2]) for row in reader]
        average_grade = sum(grades) / len(grades)
        return average_grade

def find_highest_grade(csv_file):
    with open(csv_file, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header row
        highest_grade = max(reader, key=lambda row: int(row[2]))
        return highest_grade

csv_file = 'students.csv'
average_grade = calculate_average_grade(csv_file)
highest_grade = find_highest_grade(csv_file)

print(f'Average grade: {average_grade:.2f}')
print(f'Highest grade: {highest_grade[0]} with a grade of {highest_grade[2]}')