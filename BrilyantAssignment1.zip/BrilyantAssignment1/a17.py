INSTALLED_APPS = [
    # ...
    'accounts',
    # ...
]

AUTH_USER_MODEL = 'accounts.User'