from django.db import models

class UserData(models.Model):
    name = models.CharField(max_length=255)
    age = models.IntegerField()
    bio = models.TextField()